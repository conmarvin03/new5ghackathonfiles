<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller 
{
  private $asd;
 
  function __construct()
  {
   parent::__construct(); }

 function index()
 {
$this->load->view('index_view');
 }
}
?>
