<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Registersuccess extends CI_Controller 
{
  function __construct()
  {
   parent::__construct();
   $this->load->model('register_model','register');
 }

 function index($zxc)
 {

$this->load->view('registersuccess_view',$zxc);
 }

}
?>