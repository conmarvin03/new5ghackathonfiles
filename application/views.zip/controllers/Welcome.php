<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	public function index()
	{
		if ($this->session->userdata('contestant_login')){
          
            $session_data = $this->session->userdata('contestant_login');
            $data['contestantID'] = $session_data['contestantID'];
            $data['username'] = $session_data['username'];
            $this->load->view('welcome_view', $data);
        }
        else
        {
            redirect(base_url('/login'), 'refresh');
        }
    }
    }

