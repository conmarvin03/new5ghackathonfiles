<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

  function __construct() {
        parent::__construct();
        $this->load->model('manage_model', 'manage');
    }

	public function index()
	{
		if ($this->session->userdata('employee_login')){
          
            $session_data = $this->session->userdata('employee_login');
            $data['user_id'] = $session_data['user_id'];
            $data['lname'] = $session_data['lname'];
            $data['fname'] = $session_data['fname']; 
            $data['fname'] = $session_data['fname']; 
            $data['userlevel'] = $session_data['userlevel']; 
            
            // $view= $this->manage->viewAnnouncement();   //display annnouncements
            // $data['datas'] = $view;
            $this->load->view('pages/judge/welcome_view', $data);
        }
        else
        {
            redirect(base_url('/login'), 'refresh');
        }
    }
    }

 