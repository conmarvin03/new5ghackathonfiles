<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller 
{
  private $asd;
 
  function __construct()
  {
   parent::__construct();
   $this->load->model('login_model');
 }

 function index()
 {

   $this->form_validation->set_rules('username', 'Username', 'trim|required');
   $this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');
    if($this->form_validation->run() == false)
   {
    $this->load->view('login_view');
  }
  else
  {
    $userLevel=$this->asd;
    if($userLevel=="1")
    {
   redirect(base_url('admin/welcome'), 'refresh');
    }
    elseif($userLevel=="2")
    {
   redirect(base_url('judge/welcome'), 'refresh');
    }
  
    else
    {
        redirect(base_url('/welcome'), 'refresh');
  
    }
   
}
   }
function check_database($password)
{
   //Field validation succeeded.  Validate against database
 $username = $this->input->post('username');
 $employee = $this->login_model->login($username, $password);
if($employee){
  $employee_sess = array();

  foreach($employee as $row)
  {
   $employee_sess = array(

    'lname' =>  $row->lastName,
    'fname' =>  $row->firstName,
    'user_id' => $row->userID,
    'username' => $row->username,

    'userlevel' => $row->userLvl,

  );

   $this->session->set_userdata('employee_login', $employee_sess);
 }
 $this->asd=$row->userLvl;
 return TRUE;
}
else
{
  $contestant=$this->login_model->logincontestant($username, $password);
  if($contestant)
  {
  $conestant_sess = array();

  foreach($contestant as $row)
  {
   $contestant_sess = array(
    'username' =>  $row->username,
    'contestantID' => $row->contestantID


  );

   $this->session->set_userdata('contestant_login', $contestant_sess);
 }
 return TRUE;

  }
  else{
 $this->form_validation->set_message('check_database', '<h4 style="color:red;">Invalid username or password</h4>');
 return false;
}}
}

}

?>