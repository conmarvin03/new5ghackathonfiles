<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Globe-5G Competition</title>
   <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
     
        <link href="css/styles.css" rel="stylesheet" />
        <style type="text/css">
            
header.mastheads {
  padding-top: 10.5rem;
  padding-bottom: 6rem;
  text-align: center;
  color: #fff;
  background-image: url("img/original.jfif");
  background-repeat: no-repeat;
  background-attachment: scroll;
  background-position: center center;
  background-size: cover;
  height:1000px;
}
header.mastheads .mastheads-subheading {
  font-size: 1.5rem;
  font-style: italic;
  line-height: 1.5rem;
  margin-bottom: 25px;
  font-family: "Droid Serif", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}
header.mastheads .mastheads-heading {
  font-size: 3.25rem;
  font-weight: 700;
  line-height: 3.25rem;
  margin-bottom: 2rem;
  font-family: "Montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
}

@media (min-width: 768px) {
  header.mastheads {
    padding-top: 17rem;
    padding-bottom: 12.5rem;
  }
  header.mastheads .mastheads-subheading {
    font-size: 2.25rem;
    font-style: italic;
    line-height: 2.25rem;
    margin-bottom: 2rem;
  }
  header.mastheads .mastheads-heading {
    font-size: 4.5rem;
    font-weight: 700;
    line-height: 4.5rem;
    margin-bottom: 4rem;
  }
}

.programs
{
      height:800px;

}

        </style>
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="<?=base_url()?>"><img src="img/" alt="LOGO" /></a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ml-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ml-auto">
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="<?=base_url()?>">Event Detail</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="<?=base_url()?>">Guidelines</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="<?=base_url()?>">Program</a></li>
                        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="<?=base_url()?>">Speakers</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <section class="page-section" id="contact" style="height: 969px;">
           
            <div class="container">
             <?php
if($this->session->flashdata('success_msg'))
{
?>

<div class="alert alert-success">
   <h1> <?php echo $this->session->flashdata('success_msg'); ?></h1>

<?php } ?>
</div>

<?php
if($this->session->flashdata('error_msg'))
{
?>
<div class="alert alert-danger">
<h3>    <?php echo $this->session->flashdata('error_msg'); ?></h3></div> 
<?php } ?>

       
                <div class="text-center">
                  <br>                



  <br>                  <br>
                    <h2 class="section-heading text-uppercase">Login</h2>
                    <h3 class="section-subheading text-muted">Use your team name and password.</h3>
                </div>

                         
<div class="row"><div class="col-sm-3"></div><div class="col-sm-6">
      <form class="login-form" method="POST" action="<?= site_url('login')?>">
           <?php session_destroy();  ?>
                          <?php echo validation_errors();
                          ?>
          <input  name="username" class="form-control" placeholder="Username" required="required">
       <br>
          <input type="password" name="password" class="form-control" placeholder="Password" required="required" >
    
       <br>            <a class="btn btn-primary btn-md text-uppercase" href="<?=base_url()?>registernew">
          Register</a>

            <input type="submit" class="btn btn-secondary btn-md text-uppercase" style="float:right;"  value="Sign In"></input>
       </div>
     
      </div>
    </form>
            </div>
        <!-- Services-->
   </div>
 </header>
</body>
</body>

        <!-- Bootstrap core JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Third party plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
        <!-- Contact form JS-->
        <script src="assets/mail/jqBootstrapValidation.js"></script>
        <script src="assets/mail/contact_me.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>